# orders/email.py

# ... (здесь должны быть все ваши функции send_..._email)
#  **Удалите** кастомный шаблон `templates/admin/orders/order/change_form.html`. Он больше не нужен, так как мы убрали кастомную кнопку.